[[mutuals.club]]




## Information about your business


**Please write an overview (500 characters max) of what your business does**



![[Company Description]]

**If you were to describe your business in a tweet (up to 280 characters) how would you describe it?**

![[Tweet Pitch]]




## Basic Info

**What year did you start your business?**

2022

**What is your business model?**

Subscription Service

**Who is your target audience?** (500 chars)

Young proffessionals have always had the free time, money and desire to meet new people and expand their networks. However, with hybrid work limiting in person interactions with coworkers, and many moving to new cities for a job or even experiencing much of university during lockdown, the demand is greater than ever before for in person socialising. They are busy but accustomed to instant gratification and so a frictionless AI curated events are uniquely postioned to satisfy this market demand.

**If you have a business website please add the URL below (optional)**

https://mutuals.club

**If you have social accounts for your business please include the platform (LinkedIn, Twitter etc) and handles below (optional)**

https://twitter.com/mutualsclub
youtube.com/mutualsclub

## Future
(all 500 characters max)

### What are you looking to achieve with your business over the next 6-12 months?

Deploy a full working version of my Graph Neural Network powered app with the following key features included:

- **Collect 3rd Party Networks**: Develop a consistent and reliable scraping process for, with a users consent, collecting from various social networks, profiles, shares, followers and following, likes, conection of any sort to other users and businesses.
- 
- **Safeguarding and Support**: Systems in place to check protect our club members, location sharing with selected indiviudual, prompts to call friend/family member to check in for extra reasurances. Connection to all bars, with resources if issues finding other members occur and a live chat system. 

### What are the biggest challenges you currently face with your business?
By nature, the experience we are offering is novel and unfamiliar to most, that is our USP but also our biggest demand side risk. It is clear people desire broaden their social circle but what are the conditions for this. Do they need to: attend with a friend? Have a common interest? 1, 2 or 3 levels of removal? By postioning our product as better curated events, where you meet the right people, we fit into an exisisting market consumers are aware of and avoid the challenge raising awarness of the need and benefits for a completelty **new market**.

### Why should you be given a place on the Santander X UK Awards 2022 programme? (494)
90% of the UK use social media, yet 48% report feeling lonely. We are so busy curating perfect online personas, so you'll appear on a followers feed and they might think you are cool but only if an algorithm thinks it will keep them on the platform longer. Generating in many varying levels of anixity, loneliness and depression. All the while the advertisters capitilise on the consumerism this creates. We are different, mutuals.club never advertises to our members, we connect them in person where lasting meaingful connections are best formed and mental health improved.

### How would winning the competition impact your business?

Collecting data from 3rd party networks is very important part of this business model, the bedrock of data to make this business work, at least intiially. Scraping a platform who'd prefer you not but has no legal defence, is challenging as they intentionally obsfiscate so collecting this data is time consuming. Wiining would make using services that outsource this work and risk viable. Then allowing development time to be focused on the user experience, iterating quickly on frontend app development to optimise onboarding, limit churn, increase referals and growth.




##  Scoring Rubrick

![[Potential for impact]]
  

Connects a bunch of people
Onboarding

  
  

![[Quality of Innovation]]
  

Graph Neural Networks, AI, Social Networks

Un assisted 

  

Avoid using collected data to target with 3rd party advertisements and thus maintain trust with customers. 

Business model 

  

![[Viability]]
  
  

4. [Scalability](/s" (15%): There is a clear vision to scale, and the team have made good progress with the business to date ")

  
  

5. [Competitive Advantage] (10%): The business has a unique selling point (USP) and the team can demonstrate a sound understanding of their competitors and how they compare/differ with similar products/services in the market 

  
  

6. [Team Structure] (10%): The team is well structured and has a robust plan in place to expand and build a team which will cover all key pillars of the business

## Other

### Big Picture Thinking

Web3 deployment of social networks
Use them across platform, with person authorising use of there full or partial social network for different social platforms
No longer following people on different platforms but opening up connection for certain profiles to certain networks with full visibility of the data held about you
